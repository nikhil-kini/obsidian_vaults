package com.example.batch.student;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Student {
	
	@Id
	private Integer id; // csv has id populated, @GenerateValue will give error on insertion of data
	private String firstName;
	private String lastName;
	private Integer age;
}
