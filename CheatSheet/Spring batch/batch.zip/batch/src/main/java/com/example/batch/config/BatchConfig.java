package com.example.batch.config;

import org.springframework.batch.core.job.Job;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.Step;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.infrastructure.item.data.RepositoryItemWriter;
import org.springframework.batch.infrastructure.item.file.FlatFileItemReader;
import org.springframework.batch.infrastructure.item.file.LineMapper;
import org.springframework.batch.infrastructure.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.infrastructure.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.infrastructure.item.file.transform.DelimitedLineTokenizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

import com.example.batch.student.Student;
import com.example.batch.student.StudentRepository;

import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
public class BatchConfig {
	
	private final JobRepository jobRepository;
	private final PlatformTransactionManager platformTransactionManager;
	private final StudentRepository repository;
	
    @Bean
    FlatFileItemReader<Student> itemReader(){
		FlatFileItemReader<Student> itemReader = new FlatFileItemReader<>(lineMapper());
		itemReader.setResource(new FileSystemResource("src/main/resources/student.csv")); // setting resource for reading
		itemReader.setLinesToSkip(1); // how many lines to skip from top
		return itemReader;
	}
    
    @Bean
    StudentProcessor processor() {
    	return new StudentProcessor();
    }
    
    @Bean
    RepositoryItemWriter<Student> write(){
    	RepositoryItemWriter<Student> writer = new RepositoryItemWriter<>(repository);
    	writer.setMethodName("save");
    	return writer;
    }
    
    @Bean
    Step importStep() {
    	return new StepBuilder("csvImport", jobRepository)
    			.<Student, Student>chunk(1000)  // means 1 chunk is of 1000 size
    			.transactionManager(platformTransactionManager)
    			.reader(itemReader())
    			.processor(processor())
    			.writer(write())
    			.taskExecutor(taskExecutor())
    			.build();
    }
    
    @Bean
    Job runJob() {
    	return new JobBuilder("importStudent", jobRepository)
    			.start(importStep())
    			.build();
    }
    
    @Bean
    AsyncTaskExecutor taskExecutor() {
    	SimpleAsyncTaskExecutor asyncTaskExecutor = new SimpleAsyncTaskExecutor();
    	asyncTaskExecutor.setConcurrencyLimit(4);
    	return asyncTaskExecutor;
    }

	private LineMapper<Student> lineMapper(){
		DefaultLineMapper<Student> lineMapper = new DefaultLineMapper<>();
		DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setDelimiter(",");  // setting delimiter used in csv
		lineTokenizer.setStrict(false); // setting this false means - if few entries were missing for some rows, then it can read that as well
		lineTokenizer.setNames("id", "firstName", "lastName", "age");
		
		BeanWrapperFieldSetMapper<Student> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
		fieldSetMapper.setTargetType(Student.class); // mapping with the entity - remember that Entity variables are same as CSV header names
		
		lineMapper.setLineTokenizer(lineTokenizer);
		lineMapper.setFieldSetMapper(fieldSetMapper);
		
		return lineMapper;
	}
	
	
}
