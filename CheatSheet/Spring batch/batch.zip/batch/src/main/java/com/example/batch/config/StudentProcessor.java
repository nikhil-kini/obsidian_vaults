package com.example.batch.config;

import org.jspecify.annotations.Nullable;
import org.springframework.batch.infrastructure.item.ItemProcessor;

import com.example.batch.student.Student;

public class StudentProcessor implements ItemProcessor<Student, Student>{

	@Override
	public @Nullable Student process(Student item) throws Exception {
		// TODO Auto-generated method stub
		//item.setId(null);   add this to neglect the id parameter from csv, has id is generated in @Entity with @GeneratedValue
		return item;
	}
	
}
